# Mini Python Projects

This repository contains a collection of beginner-friendly Python mini-projects by Elizabeth Waithereru Kalondu.

## Projects Included:
- Meal Plan Generator/ Healthy Meal Picker
- Greetings
- Shopping Cart
- Data Cleaner Script (placeholder)

Each project is organized into its own folder with a simple script.
