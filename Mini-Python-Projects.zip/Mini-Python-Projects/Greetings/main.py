def greet_user(name):
  return f"Hello, {name}! Welcome back😊"

user_name = input("Enter your name: ")
print(greet_user(user_name))
